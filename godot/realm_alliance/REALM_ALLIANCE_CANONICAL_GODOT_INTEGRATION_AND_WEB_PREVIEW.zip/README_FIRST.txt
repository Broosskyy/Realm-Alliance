REALM ALLIANCE - CANONICAL ART INTEGRATION PACKAGE (2026-10-16)
===============================================================

Contains the original white-haired MASKED hero, with no baked sword, five
independently replaceable weapons, four golem states, and one world plate.

NEW: preview/index.html is a playable, OFFLINE HTML combat/art visual demo.
Open it after unpacking the ZIP. It is NOT a Godot Web export and does not
provide the original game/save logic. It is for checking asset composition,
weapon hand alignment, state transitions, portrait layout and scale.

GODOT 4.7.2 integration:
The production adapters are already committed in branch:
https://github.com/Broosskyy/Realm-Alliance/tree/feature/godot-combat-foundation-01
scripts/production_hero.gd, scripts/production_enemy.gd, production_art_gate.gd.
The branch auto-switches from the existing Bramble preview only after all
16 local assets are present at res://assets/production/... and imported.

GITHUB BINARY LIMITATION / HONEST STATUS:
Those PNG files have NOT been uploaded to GitHub by this package.
Therefore the existing GitHub Actions exported APK remains the Bramble preview,
NOT this canonical production art. No release APK with these new pixels is claimed.
The asset files in this archive are correctly named for a direct merge into
existing Godot project root (the ZIP contains godot/realm_alliance/assets/...).

SOURCE ART STATUS:
- 6 weaponless original white-haired hero PNGs, all 640x512, ground y=488
- 5 independent swords, 1152x384, right-facing before socket rotation
- 4 original golem states, 736x736, ground y=704
- Wolkgarten full opaque vertical world plate, 941x1672
- Existing BRAMBLE separate combat VFX remain distinct from the character sprites.

Real phone QA is still required for weapon grip and source art proportions.

Preview screenshot: preview/CANONICAL_STAGE_COMPOSITION_REFERENCE.png
This screenshot is a PIL-composited visual target of the real sprites, not a
Godot screenshot or proof of on-device animation quality.
